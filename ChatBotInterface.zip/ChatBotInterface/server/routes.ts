import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all messages for a session
  app.get("/api/messages/:sessionId", async (req, res) => {
    try {
      const sessionId = req.params.sessionId;
      const messages = await storage.getMessagesBySessionId(sessionId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve messages" });
    }
  });

  // Send a new message
  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(messageData);
      
      // If this is a user message, generate a bot response after a short delay
      if (messageData.sender === "user") {
        setTimeout(async () => {
          const botResponse = generateBotResponse(messageData.content);
          await storage.createMessage({
            content: botResponse,
            sender: "bot",
            sessionId: messageData.sessionId
          });
        }, 1000); // Simulate processing time
      }
      
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid message data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create message" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Simple function to generate bot responses based on user input
function generateBotResponse(userMessage: string): string {
  const lowerCaseMessage = userMessage.toLowerCase();
  
  if (lowerCaseMessage.includes("meeting")) {
    return "I've noted your meeting request. Is there anything specific you'd like me to prepare for this meeting?";
  } else if (lowerCaseMessage.includes("help")) {
    return "I can help with scheduling, answering questions, or providing information. What specifically do you need assistance with?";
  } else if (lowerCaseMessage.includes("thank")) {
    return "You're welcome! Is there anything else I can help you with today?";
  } else if (lowerCaseMessage.includes("hello") || lowerCaseMessage.includes("hi")) {
    return "Hello! How can I assist you today?";
  } else {
    return "Thank you for your message. How else can I assist you today?";
  }
}
