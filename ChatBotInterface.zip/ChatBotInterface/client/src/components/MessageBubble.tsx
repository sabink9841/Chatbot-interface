import { User, Bot } from "lucide-react";
import { Message } from "@shared/schema";

interface MessageBubbleProps {
  message: Message;
}

export default function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.sender === "user";

  return (
    <div className={`flex ${isUser ? "flex-row-reverse" : ""} items-start space-x-2 sm:space-x-4 ${isUser ? "space-x-reverse" : ""}`}>
      <div className={`w-8 h-8 rounded-full ${isUser ? "bg-gray-200" : "bg-primary"} flex-shrink-0 flex items-center justify-center mt-1`}>
        {isUser ? (
          <User className="h-4 w-4 text-gray-500" />
        ) : (
          <Bot className="h-4 w-4 text-white" />
        )}
      </div>
      <div className={`${isUser ? "bg-primary text-white rounded-tr-none" : "bg-white rounded-tl-none"} rounded-lg shadow-sm p-3 sm:p-4 max-w-[85%]`}>
        <p className="text-sm sm:text-base">{message.content}</p>
      </div>
    </div>
  );
}
