import { useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import MessageBubble from "./MessageBubble";
import TypingIndicator from "./TypingIndicator";
import { Message } from "@shared/schema";

interface ChatContainerProps {
  sessionId: string;
  isTyping: boolean;
}

export default function ChatContainer({ sessionId, isTyping }: ChatContainerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { data: messages, isLoading, error } = useQuery<Message[]>({
    queryKey: [`/api/messages/${sessionId}`],
  });

  // Scroll to bottom whenever messages change or typing state changes
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  if (isLoading) {
    return (
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-light" ref={containerRef}>
        <div className="max-w-4xl mx-auto space-y-4">
          <div className="animate-pulse">
            <div className="h-12 bg-gray-200 rounded mb-2"></div>
            <div className="h-12 bg-gray-200 rounded mb-2"></div>
          </div>
        </div>
      </main>
    );
  }

  if (error) {
    return (
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-light" ref={containerRef}>
        <div className="max-w-4xl mx-auto space-y-4">
          <div className="p-4 rounded-md bg-red-50 border border-red-200">
            <p className="text-red-500">Failed to load messages. Please try again.</p>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-light" ref={containerRef}>
      <div className="max-w-4xl mx-auto space-y-4">
        {messages?.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
        
        {isTyping && <TypingIndicator />}
      </div>
    </main>
  );
}
