import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Send, Paperclip } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MessageInputProps {
  sessionId: string;
}

export default function MessageInput({ sessionId }: MessageInputProps) {
  const [message, setMessage] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest("POST", "/api/messages", {
        content,
        sender: "user",
        sessionId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/messages/${sessionId}`] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    sendMessageMutation.mutate(message);
    setMessage("");
    
    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = "56px";
    }
  };

  const handleInput = () => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    // Reset height to calculate the right height
    textarea.style.height = "56px";
    
    // Set the height based on scrollHeight, with a max height
    const newHeight = Math.min(textarea.scrollHeight, 160);
    textarea.style.height = `${newHeight}px`;
    
    // Enable scrolling if exceeds max height
    textarea.style.overflowY = newHeight >= 160 ? "auto" : "hidden";
  };

  useEffect(() => {
    // Focus textarea on component mount
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  }, []);

  return (
    <footer className="bg-white border-t border-secondary p-3 sm:p-4">
      <div className="max-w-4xl mx-auto">
        <form onSubmit={handleSubmit} className="flex items-end space-x-2">
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              className="w-full p-3 pr-10 rounded-xl border border-secondary focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none resize-none h-[56px] max-h-32"
              placeholder="Type your message here..."
              rows={1}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onInput={handleInput}
            />
            <button
              type="button"
              className="absolute bottom-3 right-3 text-gray-400 hover:text-gray-600"
              onClick={() => toast({
                title: "Coming soon",
                description: "Attachments feature is not yet available.",
              })}
            >
              <Paperclip className="h-5 w-5" />
            </button>
          </div>
          <Button
            type="submit"
            className="h-[56px] px-4 sm:px-6 bg-primary text-white rounded-xl flex items-center justify-center hover:bg-primary/90 transition-colors"
            disabled={!message.trim() || sendMessageMutation.isPending}
          >
            <Send className="h-5 w-5" />
            <span className="ml-2 hidden sm:inline">Send</span>
          </Button>
        </form>
      </div>
    </footer>
  );
}
