import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import ChatHeader from "@/components/ChatHeader";
import ChatContainer from "@/components/ChatContainer";
import MessageInput from "@/components/MessageInput";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function ChatInterface() {
  const [sessionId] = useState(() => {
    // Generate or retrieve a session ID
    return localStorage.getItem("chatSessionId") || `session_${Date.now()}`;
  });

  const [isTyping, setIsTyping] = useState(false);

  // Set up a subscription to monitor for new messages
  const { data: messages } = useQuery<any[]>({
    queryKey: [`/api/messages/${sessionId}`],
    refetchInterval: 1000, // Poll every second to check for new messages
  });

  // When a user sends a message, show typing indicator for bot response
  useEffect(() => {
    const lastMessage = messages?.[messages.length - 1];
    
    if (lastMessage?.sender === "user") {
      setIsTyping(true);
      const timer = setTimeout(() => {
        // This will be cleared once we see a bot response
        setIsTyping(false);
      }, 5000); // Fallback timeout
      
      return () => clearTimeout(timer);
    } else {
      setIsTyping(false);
    }
  }, [messages]);

  // Store session ID in localStorage
  useEffect(() => {
    localStorage.setItem("chatSessionId", sessionId);
  }, [sessionId]);

  return (
    <div className="bg-light font-sans h-screen flex flex-col text-dark">
      <ChatHeader />
      <ChatContainer sessionId={sessionId} isTyping={isTyping} />
      <MessageInput sessionId={sessionId} />
    </div>
  );
}
